const mongoose = require('mongoose');

const AuthorsSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "Name of author is required"],
        minlength: [3, "Authors name needs to be at least 3 characters long"]
    }

}, { timestamps: true });

const Authors = mongoose.model("Authors", AuthorsSchema);

// Authors.schema.path("name").validate(function (value) {
//     return !(value.length < 3 || value == "");
// })

// const opts = { runValidators: true };
// Authors.findOneAndUpdate({}, { name: 'invalid name' }, opts, function (err) {
//     console.log('err: ', err);
//     return (
//         err.errors.name.message === 'Name of author is required' ||
//         err.errors.name.message === 'Authors name needs to be at least 3 characters long'
//     );
// });

module.exports.Authors = Authors;